import requests

class GasOracle:
    """Multi-chain gas price estimation service"""
    
    SOURCES = {
        'ethereum': 'https://api.etherscan.io/api?module=gastracker&action=gasoracle',
        'polygon': 'https://gasstation-mainnet.matic.network/v2'
    }

    def get_gas_prices(self, chain: str) -> dict:
        """Get current gas prices for specified chain"""
        if chain not in self.SOURCES:
            raise ValueError(f"Unsupported chain for gas oracle: {chain}")
        
        try:
            response = requests.get(self.SOURCES[chain], timeout=10)
            response.raise_for_status()
            return self._parse_response(chain, response.json())
        except requests.exceptions.RequestException as e:
            raise ConnectionError(f"Gas oracle request failed: {str(e)}")

    def _parse_response(self, chain: str, data: dict) -> dict:
        if chain == 'ethereum':
            return {
                'low': int(data['result']['SafeGasPrice']),
                'medium': int(data['result']['ProposeGasPrice']),
                'high': int(data['result']['FastGasPrice'])
            }
        elif chain == 'polygon':
            return {
                'standard': int(data['standard']),
                'fast': int(data['fast']),
                'rapid': int(data['rapid'])
            }
        raise ValueError(f"Unsupported chain for parsing: {chain}")