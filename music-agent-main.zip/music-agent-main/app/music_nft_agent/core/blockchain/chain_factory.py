import os
from .clients.ethereum import EthereumClient
from ..security.key_manager import KeyManager
from .clients.base import BlockchainClient

class ChainFactory:
    """Factory for creating chain-specific clients using adapter pattern"""
    
    @staticmethod
    def create_client(chain_id: str, key_manager: KeyManager) -> BlockchainClient:
        chain_config = {
            'ethereum': {
                'class': EthereumClient,
                'provider_env_var': 'ETH_PROVIDER_URL'
            }
        }
        
        if chain_id not in chain_config:
            raise ValueError(f"Unsupported chain: {chain_id}")

        config = chain_config[chain_id]
        provider_url = os.getenv(config['provider_env_var'])
        if not provider_url:
            raise ValueError(f"Provider URL not found in environment for {chain_id}")
        
        client = config['class'](key_manager)
        client.connect(provider_url)
        return client