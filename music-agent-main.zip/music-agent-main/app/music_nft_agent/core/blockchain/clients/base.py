from abc import ABC, abstractmethod
from typing import Dict, Any

class BlockchainClient(ABC):
    """Base class for blockchain clients using chain-agnostic interface"""
    
    @abstractmethod
    def connect(self, provider_url: str) -> None:
        """Connect to blockchain network"""
        pass
    
    @abstractmethod
    def get_latest_block(self) -> int:
        """Get latest block number"""
        pass
    
    @abstractmethod
    def send_transaction(self, tx_data: Dict[str, Any]) -> str:
        """Send signed transaction to network"""
        pass

    @abstractmethod
    def estimate_gas(self, tx_params: Dict[str, Any]) -> int:
        """Estimate gas cost for transaction"""
        pass