from web3 import Web3
from web3.gas_strategies.time_based import medium_gas_price_strategy
from .base import BlockchainClient
from ...security.key_manager import KeyManager
import os

class BlockchainTransactionError(Exception):
    """Custom exception for blockchain transaction errors"""

class EthereumClient(BlockchainClient):
    """Ethereum client implementation with EIP-1559 support"""
    
    def __init__(self, key_manager: KeyManager):
        self.web3 = None
        self.key_manager = key_manager
        self.gas_oracle = medium_gas_price_strategy

    def connect(self, provider_url: str) -> None:
        if not provider_url:
            raise ValueError("Ethereum provider URL not configured")
        self.web3 = Web3(Web3.HTTPProvider(provider_url))
        if not self.web3.is_connected():
            raise ConnectionError("Failed to connect to Ethereum network")

    def get_latest_block(self) -> int:
        return self.web3.eth.block_number

    def estimate_gas(self, tx_params: Dict[str, Any]) -> int:
        return self.web3.eth.estimate_gas(tx_params)

    def send_transaction(self, tx_data: Dict[str, Any]) -> str:
        try:
            if not self.web3:
                raise BlockchainTransactionError("Not connected to Ethereum network")
            
            tx_data['nonce'] = self.web3.eth.get_transaction_count(tx_data['from'])
            
            # EIP-1559 gas estimation
            if 'maxFeePerGas' not in tx_data:
                fee_history = self.web3.eth.fee_history(1, 'latest')
                base_fee = fee_history['baseFeePerGas'][0]
                max_priority = self.web3.to_wei(1.5, 'gwei')
                max_fee = base_fee + max_priority
                tx_data.update({
                    'maxFeePerGas': max_fee,
                    'maxPriorityFeePerGas': max_priority
                })

            # Sign transaction using HSM
            signed_tx = self.key_manager.sign_transaction(tx_data, 'ethereum')
            tx_hash = self.web3.eth.send_raw_transaction(signed_tx)
            return tx_hash.hex()
        
        except Exception as e:
            raise BlockchainTransactionError(f"Ethereum TX failed: {str(e)}")