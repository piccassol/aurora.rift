import boto3
from botocore.exceptions import ClientError
from web3 import Web3

class SecurityError(Exception):
    """Custom exception for security-related errors"""

class KeyManager:
    """Secure key management using AWS KMS"""
    
    def __init__(self, kms_key_id: str):
        self.kms = boto3.client('kms')
        self.key_id = kms_key_id

    def sign_transaction(self, tx_data: dict, chain_type: str) -> bytes:
        """Sign transaction using HSM-stored keys"""
        try:
            if chain_type == 'ethereum':
                return self._sign_ethereum(tx_data)
            raise NotImplementedError(f"Signing for {chain_type} not implemented")
        except ClientError as e:
            raise SecurityError(f"KMS signing failed: {str(e)}")

    def _der_to_rs(self, der_signature: bytes) -> tuple:
        """Convert DER-encoded signature to R/S components"""
        if der_signature[0] != 0x30:
            raise SecurityError("Invalid DER signature")
        length = der_signature[1]
        der_signature = der_signature[2:2+length]
        
        if der_signature[0] != 0x02:
            raise SecurityError("Invalid R component")
        r_length = der_signature[1]
        r = int.from_bytes(der_signature[2:2+r_length], 'big')
        der_signature = der_signature[2+r_length:]
        
        if der_signature[0] != 0x02:
            raise SecurityError("Invalid S component")
        s_length = der_signature[1]
        s = int.from_bytes(der_signature[2:2+s_length], 'big')
        
        return r, s

    def _sign_ethereum(self, tx_data: dict) -> bytes:
        """Sign Ethereum transaction using ECDSA"""
        tx_hash = Web3.keccak(text=str(tx_data))
        response = self.kms.sign(
            KeyId=self.key_id,
            Message=tx_hash,
            MessageType='DIGEST',
            SigningAlgorithm='ECDSA_SHA_256'
        )
        r, s = self._der_to_rs(response['Signature'])
        
        # Get recovery ID (v) from public key (simplified example)
        # In production, implement proper recovery ID calculation
        v = 27  # Placeholder value for demonstration
        
        return r.to_bytes(32, 'big') + s.to_bytes(32, 'big') + bytes([v])

    def get_decrypted_env(self, encrypted_env: str) -> str:
        """Decrypt environment variables using KMS"""
        try:
            response = self.kms.decrypt(
                CiphertextBlob=bytes.fromhex(encrypted_env)
            )
            return response['Plaintext'].decode('utf-8')
        except ClientError as e:
            raise SecurityError(f"Decryption failed: {str(e)}")
        except ValueError as e:
            raise SecurityError(f"Invalid hex encoding: {str(e)}")